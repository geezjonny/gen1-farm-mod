# Pokemon Farm

The opposite of a catch-everything mod: a place for Pokemon you let go.

## What it does

- Adds a **FARM** entry to the Start menu and/or PC (configurable).
- FARM opens a hub with two choices: **SEND TO FARM** (party + current box,
  merged) and **VIEW FARM (n)**.
- Picking a Pokemon in SEND moves it into `save.farm`. Picking one in VIEW
  reclaims it — Party if there's room, else the current Box, else it's put
  back in the farm rather than lost.
- Vanilla release is untouched. This is a second option living next to it.

## Version history

**v0.2.0 (current)** — rebuilt around the engine's own `ListMenu`/`TextBox`
widgets after v0.1.0's hand-rolled screen didn't respond to input in
testing. `ListMenu` handles all input itself; the mod just supplies rows
and an `onChoose` callback, confirmed directly from `MULTI_SAVE_SLOTS`
v1.0.0's real source.

**v0.1.0** — first pass: a fully custom screen (`mod.content.screens:register`
+ hand-written `self:update()`/`self:draw()`, polling
`game.input:wasPressed(...)`). Manifest loaded, the screen rendered, but no
button press did anything — the input loop never fired or errored
silently (mod callbacks are pcall-isolated per the wiki, so a bad call
just goes quiet rather than crashing). Kept `save.party`/`save.boxes`/
`save.farm` splicing logic from this version since it never depended on
the input layer.

## Confirmed real API used here

From `gen1recomp-gen3-boxes` v1.5.2:
- `require("src.pokemon.Boxes")`, `require("src.pokemon.Party")` — mods
  can pull engine source directly with the `engine_internals` permission.
- `game.save.boxes[game.save.currentBox]` / `game.save.party` are the real
  storage arrays; `Boxes.ensure(game.save)` backfills a missing table.
- `mod.hooks:wrap("ui.start_menu.items"/"ui.pc.items", function(next, game, items) ... end)`
  — call `next()` first, decorate, return.
- `mod.ui.insertBefore(list, anchorLabel, row)` / `insertAfter(...)`.
- `mod.options:define({...})` / `mod.options:get(key)`.

From `MULTI_SAVE_SLOTS` v1.0.0:
- `require("src.ui.ListMenu")`, `require("src.render.TextBox")`.
- `game.stack:push(ListMenu.new(game, title, rows, { onChoose = function(item, menu) ... end }))`
  — the engine handles all input; `onChoose` fires per selection.
- `game.stack:push(TextBox.new(game, message))` for a one-line notice.
- Rebuilding a menu in place after an action: reassign `menu.items`, clamp
  `menu.index`, reset `menu.scroll = 0`, call `menu:close()` if now empty.

## What's still unverified

The manifest's `permissions`/`profile`/`game_version` field names came
from a mix of the loader's own validation errors (it required `name`,
confirmed by testing) and inference from other mods — worth a final check
against `src/mods/Manifest.lua` directly if anything else gets flagged.

Run `python3 tools/modkit.py validate pokemon_farm --base imported` to
check.
